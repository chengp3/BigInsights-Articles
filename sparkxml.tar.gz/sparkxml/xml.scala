import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions
 
val spark = SparkSession.builder.getOrCreate()
 
//Read all the xmls from HDFS
var nfmp2df = spark.read.format("com.databricks.spark.xml").option("rowTag", "edgarSubmission").load("/ws/oozie/")
 
//explode scheduleOfPortfolioSecuritiesInfo section
var portfolioSecuritiesDF = nfmp2df.select(
nfmp2df.col("formData.generalInfo.cik") as ("nfmp_cik"), nfmp2df.col("formData.generalInfo.reportDate") as ("reportDate"), functions.explode(nfmp2df.col("formData.scheduleOfPortfolioSecuritiesInfo")).as("securities")).select(
"nfmp_cik","reportDate",
"securities.nameOfIssuer",
"securities.titleOfIssuer",
"securities.CUSIPMember",
"securities.LEIID",
"securities.ISINId",
"securities.cik",
"securities.otherUniqueId",
"securities.investmentCategory",
"securities.briefDescription",
"securities.fundAcqstnUndrlyngSecurityFlag",
"securities.repurchaseAgreement",
"securities.repurchaseAgreement.repurchaseAgreementOpenFlag",
"securities.securityEligibilityFlag",
"securities.NRSRO",
"securities.investmentMaturityDateWAM",
"securities.investmentMaturityDateWAL",
"securities.finalLegalInvestmentMaturityDate",
"securities.securityDemandFeatureFlag",
"securities.demandFeature",
"securities.securityGuaranteeFlag",
"securities.securityEnhancementsFlag",
"securities.yieldOfTheSecurityAsOfReportingDate",
"securities.includingValueOfAnySponsorSupport",
"securities.excludingValueOfAnySponsorSupport",
"securities.percentageOfMoneyMarketFundNetAssets",
"securities.securityCategorizedAtLevel3Flag",
"securities.dailyLiquidAssetSecurityFlag",
"securities.weeklyLiquidAssetSecurityFlag",
"securities.illiquidSecurityFlag",
"securities.explanatoryNotes")
 
var portfolioSecuritiesDF2 = portfolioSecuritiesDF.select(
"nfmp_cik","reportDate","nameOfIssuer","titleOfIssuer","CUSIPMember","LEIID","ISINId","cik","otherUniqueId","investmentCategory","briefDescription",
"fundAcqstnUndrlyngSecurityFlag","repurchaseAgreementOpenFlag","securityEligibilityFlag","investmentMaturityDateWAM","investmentMaturityDateWAL",
"finalLegalInvestmentMaturityDate","securityDemandFeatureFlag","securityGuaranteeFlag","securityEnhancementsFlag","yieldOfTheSecurityAsOfReportingDate",
"includingValueOfAnySponsorSupport","excludingValueOfAnySponsorSupport","percentageOfMoneyMarketFundNetAssets","securityCategorizedAtLevel3Flag",
"dailyLiquidAssetSecurityFlag","weeklyLiquidAssetSecurityFlag","illiquidSecurityFlag","explanatoryNotes")
 
//Explode collateralIssuers section
var collateralIssuersDF = portfolioSecuritiesDF.select(
portfolioSecuritiesDF.col("nfmp_cik"), portfolioSecuritiesDF.col("reportDate"), portfolioSecuritiesDF.col("nameOfIssuer"), portfolioSecuritiesDF.col("CUSIPMember"),
functions.explode(portfolioSecuritiesDF.col("repurchaseAgreement.collateralIssuers")).as("collateralIssuers")).
select("nfmp_cik","reportDate","nameOfIssuer","CUSIPMember","collateralIssuers.nameOfCollateralIssuer","collateralIssuers.LEIID",
"collateralIssuers.maturityDate.dateRange.nmfp2common:from","collateralIssuers.maturityDate.dateRange.nmfp2common:to","collateralIssuers.couponOrYield","collateralIssuers.principalAmountToTheNearestCent",
"collateralIssuers.valueOfCollateralToTheNearestCent","collateralIssuers.ctgryInvestmentsRprsntsCollateral")
 
//explode classLevelInfo into another data frame
var classLevelInfoDF = nfmp2df.select(
nfmp2df.col("formData.generalInfo.cik") as ("cik"), nfmp2df.col("formData.generalInfo.reportDate") as ("reportDate"), functions.explode(nfmp2df.col("formData.classLevelInfo")).as("classLevelInfo"))
 
classLevelInfoDF = classLevelInfoDF.select(
classLevelInfoDF.col("cik"),
classLevelInfoDF.col("reportDate"),
classLevelInfoDF.col("classLevelInfo.classesId"),
classLevelInfoDF.col("classLevelInfo.minInitialInvestment"),
classLevelInfoDF.col("classLevelInfo.netAssetsOfClass"),
classLevelInfoDF.col("classLevelInfo.numberOfSharesOutstanding"), classLevelInfoDF.col("classLevelInfo.netAssetPerShare.nmfp2common:fridayWeek1").as("netAssetPerShare_nmfp2common_fridayWeek1"),
classLevelInfoDF.col("classLevelInfo.netAssetPerShare.nmfp2common:fridayWeek2").as("netAssetPerShare_nmfp2common_fridayWeek2"),
classLevelInfoDF.col( "classLevelInfo.netAssetPerShare.nmfp2common:fridayWeek3").as("netAssetPerShare_nmfp2common_fridayWeek3"),
classLevelInfoDF.col( "classLevelInfo.netAssetPerShare.nmfp2common:fridayWeek4").as("netAssetPerShare_nmfp2common_fridayWeek4"),
classLevelInfoDF.col("classLevelInfo.fridayWeek1.weeklyGrossSubscriptions").as("fridayWeek1_weeklyGrossSubscriptions"),
classLevelInfoDF.col("classLevelInfo.fridayWeek1.weeklyGrossRedemptions").as("fridayWeek1_weeklyGrossRedemptions"),
classLevelInfoDF.col("classLevelInfo.fridayWeek2.weeklyGrossSubscriptions").as("fridayWeek2_weeklyGrossSubscriptions"),
classLevelInfoDF.col("classLevelInfo.fridayWeek2.weeklyGrossRedemptions").as("fridayWeek2_weeklyGrossRedemptions"),
classLevelInfoDF.col("classLevelInfo.fridayWeek3.weeklyGrossSubscriptions").as("fridayWeek3_weeklyGrossSubscriptions"),
classLevelInfoDF.col("classLevelInfo.fridayWeek3.weeklyGrossRedemptions").as("fridayWeek3_weeklyGrossRedemptions"),
classLevelInfoDF.col("classLevelInfo.fridayWeek4.weeklyGrossSubscriptions").as("fridayWeek4_weeklyGrossSubscriptions"),
classLevelInfoDF.col("classLevelInfo.fridayWeek4.weeklyGrossRedemptions").as("fridayWeek4_weeklyGrossRedemptions"),
classLevelInfoDF.col("classLevelInfo.totalForTheMonthReported.weeklyGrossSubscriptions").as("totalForTheMonthReported_weeklyGrossSubscriptions"),
classLevelInfoDF.col("classLevelInfo.totalForTheMonthReported.weeklyGrossRedemptions").as("totalForTheMonthReported_weeklyGrossRedemptions"),
classLevelInfoDF.col("classLevelInfo.sevenDayNetYield"),classLevelInfoDF.col("classLevelInfo.personPayForFundFlag"))
 
//moneyMarketFundCategory
var moneyMarketFundCategoryDF = nfmp2df.select(
nfmp2df.col("formData.generalInfo.cik") as ("cik"), nfmp2df.col("formData.generalInfo.reportDate") as ("reportDate"), nfmp2df.col("formData.seriesLevelInfo.moneyMarketFundCategory") as ("category"))
 
//extract series level
var seriesLevelDF=nfmp2df.select(
nfmp2df.col("headerData.submissionType"),
nfmp2df.col("formData.generalInfo.cik"),
nfmp2df.col("formData.generalInfo.reportDate"),
nfmp2df.col("formData.seriesLevelInfo.securitiesActFileNumber"),
nfmp2df.col("formData.seriesLevelInfo.adviser.adviserName"),
nfmp2df.col("formData.seriesLevelInfo.adviser.adviserFileNumber"),
nfmp2df.col("formData.seriesLevelInfo.subAdviser.adviserName").as("subAdviserName"),
nfmp2df.col("formData.seriesLevelInfo.subAdviser.adviserFileNumber").as("subAdvisorNumber"),
nfmp2df.col("formData.seriesLevelInfo.indpPubAccountant.name").as("indpPubAcct_name"),
nfmp2df.col("formData.seriesLevelInfo.indpPubAccountant.city").as("indpPubAcct_city"),
nfmp2df.col("formData.seriesLevelInfo.indpPubAccountant.stateCountry").as("indpPubAcct_state"),
nfmp2df.col("formData.seriesLevelInfo.administrator.administratorName"),
nfmp2df.col("formData.seriesLevelInfo.transferAgent.name").as("ta_name"),
nfmp2df.col("formData.seriesLevelInfo.transferAgent.cik").as("ta_cik"),
nfmp2df.col("formData.seriesLevelInfo.transferAgent.fileNumber").as("ta_fileNumber"),
nfmp2df.col("formData.seriesLevelInfo.feederFundFlag"),
nfmp2df.col("formData.seriesLevelInfo.masterFundFlag"),
nfmp2df.col("formData.seriesLevelInfo.seriesFundInsuCmpnySepAccntFlag"),
nfmp2df.col("formData.seriesLevelInfo.fundExemptRetailFlag"),
nfmp2df.col("formData.seriesLevelInfo.averagePortfolioMaturity"),
nfmp2df.col("formData.seriesLevelInfo.averageLifeMaturity"),
nfmp2df.col("formData.seriesLevelInfo.totalValueDailyLiquidAssets.nmfp2common:fridayDay1").as("totalValueDailyLiquidAssets_fridayDay1"),
nfmp2df.col("formData.seriesLevelInfo.totalValueDailyLiquidAssets.nmfp2common:fridayDay2").as("totalValueDailyLiquidAssets_fridayDay2"),
nfmp2df.col("formData.seriesLevelInfo.totalValueDailyLiquidAssets.nmfp2common:fridayDay3").as("totalValueDailyLiquidAssets_fridayDay3"),
nfmp2df.col("formData.seriesLevelInfo.totalValueDailyLiquidAssets.nmfp2common:fridayDay4").as("totalValueDailyLiquidAssets_fridayDay4"),
nfmp2df.col("formData.seriesLevelInfo.totalValueWeeklyLiquidAssets.nmfp2common:fridayWeek1").as("totalValueWeeklyLiquidAssets_fridayWeek1"),
nfmp2df.col("formData.seriesLevelInfo.totalValueWeeklyLiquidAssets.nmfp2common:fridayWeek2").as("totalValueWeeklyLiquidAssets_fridayWeek2"),
nfmp2df.col("formData.seriesLevelInfo.totalValueWeeklyLiquidAssets.nmfp2common:fridayWeek3").as("totalValueWeeklyLiquidAssets_fridayWeek3"),
nfmp2df.col("formData.seriesLevelInfo.totalValueWeeklyLiquidAssets.nmfp2common:fridayWeek4").as("totalValueWeeklyLiquidAssets_fridayWeek4"),
nfmp2df.col("formData.seriesLevelInfo.percentageDailyLiquidAssets.nmfp2common:fridayDay1").as("percentageDailyLiquidAssets_fridayWeek1"),
nfmp2df.col("formData.seriesLevelInfo.percentageDailyLiquidAssets.nmfp2common:fridayDay2").as("percentageDailyLiquidAssets_fridayWeek2"),
nfmp2df.col("formData.seriesLevelInfo.percentageDailyLiquidAssets.nmfp2common:fridayDay3").as("percentageDailyLiquidAssets_fridayWeek3"),
nfmp2df.col("formData.seriesLevelInfo.percentageDailyLiquidAssets.nmfp2common:fridayDay4").as("percentageDailyLiquidAssets_fridayWeek4"),
nfmp2df.col("formData.seriesLevelInfo.percentageWeeklyLiquidAssets.nmfp2common:fridayWeek1").as("percentageWeeklyLiquidAssets_fridayWeek1"),
nfmp2df.col("formData.seriesLevelInfo.percentageWeeklyLiquidAssets.nmfp2common:fridayWeek2").as("percentageWeeklyLiquidAssets_fridayWeek2"),
nfmp2df.col("formData.seriesLevelInfo.percentageWeeklyLiquidAssets.nmfp2common:fridayWeek3").as("percentageWeeklyLiquidAssets_fridayWeek3"),
nfmp2df.col("formData.seriesLevelInfo.percentageWeeklyLiquidAssets.nmfp2common:fridayWeek4").as("percentageWeeklyLiquidAssets_fridayWeek4"),
nfmp2df.col("formData.seriesLevelInfo.cash"),
nfmp2df.col("formData.seriesLevelInfo.totalValuePortfolioSecurities"),
nfmp2df.col("formData.seriesLevelInfo.amortizedCostPortfolioSecurities"),
nfmp2df.col("formData.seriesLevelInfo.totalValueOtherAssets"),
nfmp2df.col("formData.seriesLevelInfo.totalValueLiabilities"),
nfmp2df.col("formData.seriesLevelInfo.netAssetOfSeries"),
nfmp2df.col("formData.seriesLevelInfo.numberOfSharesOutstanding"),
nfmp2df.col("formData.seriesLevelInfo.stablePricePerShare"),
nfmp2df.col("formData.seriesLevelInfo.sevenDayGrossYield"),
nfmp2df.col("formData.seriesLevelInfo.netAssetValue.nmfp2common:fridayWeek1").as("netAssetValue_fridayWeek1"),
nfmp2df.col("formData.seriesLevelInfo.netAssetValue.nmfp2common:fridayWeek2").as("netAssetValue_fridayWeek2"),
nfmp2df.col("formData.seriesLevelInfo.netAssetValue.nmfp2common:fridayWeek3").as("netAssetValue_fridayWeek3"),
nfmp2df.col("formData.seriesLevelInfo.netAssetValue.nmfp2common:fridayWeek4").as("netAssetValue_fridayWeek4"))
 
//This Section is to save dataframes extracted from xml into temp table
nfmp2df.createOrReplaceTempView("nfmpTT")
portfolioSecuritiesDF2.createOrReplaceTempView("portfolioSecuritiesTT")
classLevelInfoDF.createOrReplaceTempView("classLevelInfoTT")
moneyMarketFundCategoryDF.createOrReplaceTempView("moneyMarketFundCategoryTT")
collateralIssuersDF.createOrReplaceTempView("collateralIssuersTT")
seriesLevelDF.createOrReplaceTempView("seriesLevelTT")
 
//Create Hive table from the temp table
spark.sql("create database SPARK_TEST")

spark.sql("DROP TABLE IF EXISTS SPARK_TEST.NFMP_PORTFOLIO_SECURITIES_T")
spark.sql("DROP TABLE IF EXISTS SPARK_TEST.NFMP_classLevel_T")
spark.sql("DROP TABLE IF EXISTS SPARK_TEST.NFMP_moneyMarketFundCategory_T")
spark.sql("DROP TABLE IF EXISTS SPARK_TEST.NFMP_collateralIssuers_T")
spark.sql("DROP TABLE IF EXISTS SPARK_TEST.NFMP_GENERALINFO_T")
spark.sql("DROP TABLE IF EXISTS SPARK_TEST.NFMP_SERIESLEVEL_T")
 
spark.sql("create table SPARK_TEST.NFMP_PORTFOLIO_SECURITIES_T as select * from portfolioSecuritiesTT")
spark.sql("create table SPARK_TEST.NFMP_classLevel_T as select * from classLevelInfoTT")
spark.sql("create table SPARK_TEST.NFMP_moneyMarketFundCategory_T as select * from moneyMarketFundCategoryTT")
spark.sql("create table SPARK_TEST.NFMP_collateralIssuers_T as select * from collateralIssuersTT")
spark.sql("create table SPARK_TEST.NFMP_GENERALINFO_T as select headerData.submissionType, formData.generalInfo.reportDate, formData.generalInfo.cik as cik, formData.generalInfo.registrantLEIId, formData.generalInfo.seriesId, formData.generalInfo.totalShareClassesInSeries, formData.generalInfo.finalFilingFlag,formData.generalInfo.fundAcqrdOrMrgdWthAnthrFlag from nfmpTT")
spark.sql("create table SPARK_TEST.NFMP_SERIESLEVEL_T as select * from seriesLevelTT")

System.exit(0)
