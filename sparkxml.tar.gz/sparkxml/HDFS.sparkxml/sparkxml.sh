spark-shell -i /ws/sparkxml/xml.scala --jars /ws/sparkxml/spark-xml_2.11-0.4.1.jar --driver-memory 5g
